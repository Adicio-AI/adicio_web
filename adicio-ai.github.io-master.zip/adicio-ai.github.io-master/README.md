# adicio-ai.github.io
Adicio Projects
A Test of the Readme file. Does it render with Jekyll? It seems not. I'll play with it later.
